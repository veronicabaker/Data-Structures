
public class AbsoluteValue implements DoubleDoubleFunction
{
	public double apply(double x)
	{
		return Math.abs(x);
	}
}
